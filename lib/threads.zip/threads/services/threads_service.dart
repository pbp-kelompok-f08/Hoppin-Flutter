import 'dart:convert';
import 'package:pbp_django_auth/pbp_django_auth.dart';

import '../models/threads_models.dart';
import '../models/reply_models.dart';

class ThreadsService {
  static const String baseUrl = "http://127.0.0.1:8000"; // ganti kalau emulator/device
  final CookieRequest request;

  ThreadsService(this.request);

  Future<List<Threads>> fetchThreads() async {
    final res = await request.get("$baseUrl/threads/show-json/");
    if (res is List) {
      return res.map((e) => Threads.fromJson(e as Map<String, dynamic>)).toList();
    }
    if (res is String) {
      return threadsFromJson(res);
    }
    return [];
  }

  Future<Map<String, dynamic>> likeThread(String threadId) async {
    final res = await request.post("$baseUrl/threads/like-thread/$threadId/", {});
    return (res as Map).cast<String, dynamic>();
  }

  Future<List<Reply>> fetchReplies(String threadId) async {
    final res = await request.get("$baseUrl/threads/replies/$threadId/");
    if (res is List) {
      return res.map((e) => Reply.fromJson(e as Map<String, dynamic>)).toList();
    }
    if (res is String) {
      return replyFromJson(res);
    }
    return [];
  }

  Future<Map<String, dynamic>> likeReply(String replyId) async {
    final res = await request.post("$baseUrl/threads/like-reply/$replyId/", {});
    return (res as Map).cast<String, dynamic>();
  }

  Future<Map<String, dynamic>> addReply(String threadId, String content) async {
    final res = await request.post(
      "$baseUrl/threads/create-reply-ajax/$threadId/",
      {"content": content},
    );
    return (res as Map).cast<String, dynamic>();
  }

  Future<void> createThread({
    required String content,
    required String tags,
    required String imageUrl,
  }) async {
    await request.post(
      "$baseUrl/threads/add-thread-entry-ajax/",
      {"content": content, "tags": tags, "image": imageUrl},
    );
  }

  Future<String> fetchCurrentUsername() async {
    final res = await request.get("$baseUrl/accounts/profile-detail/");
    if (res is Map && res["username"] != null) return res["username"].toString();
    return "";
  }
}
